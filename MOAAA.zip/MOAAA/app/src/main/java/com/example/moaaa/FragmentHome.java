package com.example.moaaa;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public abstract class FragmentHome extends AppCompatActivity implements InterFaceFireBase {

    CardView cd2, cd3;
    TextView tvm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment_home);

        cd2 = findViewById(R.id.cardView2);
        tvm = findViewById(R.id.tvmarq);
        tvm.setSelected(true);

        cd2.setOnClickListener(view -> {
            Intent intent = new Intent(this, ActivityWorkOut.class);
            startActivity(intent);
        });

        cd3.setOnClickListener(view -> {
            Intent intent = new Intent(this, BmiActivityCalc.class);
            startActivity(intent);
        });
    }
}
