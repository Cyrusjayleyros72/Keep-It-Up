package com.example.moaaa;

public class Users {
    String email;
    int password;

    public Users(String email, String password) {

    }

    public Users(int password, String email) {
        this.password = password;
        this.email = email;
    }

    public Users(String email) {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getPassword() {
        return password;
    }

    public void setPassword(int password) {
        this.password = password;
    }
}
