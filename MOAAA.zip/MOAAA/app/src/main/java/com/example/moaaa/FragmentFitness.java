package com.example.moaaa;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class FragmentFitness extends AppCompatActivity {

    public static class FitnessFragment extends Fragment {

        ImageView img;
        ImageView img2;
        ImageView img3;

        private static final String ARG_PARAM1 = "param1";
        private static final String ARG_PARAM2 = "param2";

        public void fragment_fitness() {
        }

        public FitnessFragment newInstance(String param1, String param2) {
            FitnessFragment fragment = new FitnessFragment();
            Bundle args = new Bundle();
            args.putString(ARG_PARAM1, param1);
            args.putString(ARG_PARAM2, param2);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            if (getArguments() != null) {
                String mParam1 = getArguments().getString(ARG_PARAM1);
                String mParam2 = getArguments().getString(ARG_PARAM2);
            }
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.activity_fragment_fitness, container, false);

            img = view.findViewById(R.id.bmibtn1);
            img2 = view.findViewById(R.id.wellbtn1);
            img3 = view.findViewById(R.id.tipsbtn1);

            img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getActivity(), BmiActivityCalc.class);
                    startActivity(intent);
                }
            });


            img2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getActivity(), ActivityWellness.class);
                    startActivity(intent);
                }
            });

            img3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getActivity(), ActivityTips.class);
                    startActivity(intent);
                }
            });

            return view;
        }

        private void gotoUri(String s) {
            Uri uri = Uri.parse(s);
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        }
    }
}