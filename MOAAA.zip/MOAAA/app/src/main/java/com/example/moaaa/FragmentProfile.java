package com.example.moaaa;

import static android.app.PendingIntent.getActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;

import java.util.ResourceBundle;

public class FragmentProfile extends AppCompatActivity {

    public static final String TAG = "TAG";
    ImageView img;
    Button btn,updatebtn;
    EditText kg,cm;
    TextInputLayout name,email,contact;
    private com.example.moaaa.FirebaseFirestore firestore;
    com.example.moaaa.FirebaseAuth fAuth;
    String userID;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    public FragmentProfile() {
    }

    public static FragmentProfile newInstance(String param1, String param2) {
        FragmentProfile fragment = new FragmentProfile();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    private void setArguments(Bundle args) {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            String mParam1 = getArguments().getString(ARG_PARAM1);
            String mParam2 = getArguments().getString(ARG_PARAM2);
        }

    }

    private ResourceBundle getArguments() {
        return null;
    }

    private static class FirebaseFirestore {
        private static com.example.moaaa.FirebaseFirestore instance;

        public static com.example.moaaa.FirebaseFirestore getInstance() {

            return instance;
        }

        public static void setInstance(com.example.moaaa.FirebaseFirestore instance) {
            FirebaseFirestore.instance = instance;
        }
    }
}