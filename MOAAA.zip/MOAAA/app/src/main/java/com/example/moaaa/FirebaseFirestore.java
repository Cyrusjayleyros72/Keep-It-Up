package com.example.moaaa;

public interface FirebaseFirestore {
}
