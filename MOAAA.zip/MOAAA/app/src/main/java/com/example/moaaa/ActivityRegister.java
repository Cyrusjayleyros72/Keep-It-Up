package com.example.moaaa;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.moaaa.databinding.ActivityRegisterBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ActivityRegister extends AppCompatActivity {

    private ActivityRegisterBinding binding;
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private ProgressDialog progressDialog;
    private String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        mAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);

        // Redirect to Login if "Already have an account" is clicked
        binding.haveAccount.setOnClickListener(v -> {
            startActivity(new Intent(ActivityRegister.this, ActivityLogin.class));
        });

        // Handle Register Button Click
        binding.btnRegister.setOnClickListener(v -> {
            performAuth();
        });
    }

    private void performAuth() {
        String email = binding.inputEmail.getText().toString().trim();
        String password = binding.inputPassword.getText().toString().trim();

        if (!email.matches(emailPattern)) {
            binding.inputEmail.setError("Enter a valid email");
        } else if (password.isEmpty() || password.length() < 6) {
            binding.inputPassword.setError("Password must be ≥6 characters");
        } else {
            progressDialog.show();
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            saveUserToDatabase(email);
                            sendUserToNextActivity();
                        } else {
                            Toast.makeText(this, "Error: " + task.getException(), Toast.LENGTH_SHORT).show();
                        }
                        progressDialog.dismiss();
                    });
        }
    }

    private void saveUserToDatabase(String email) {
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference reference = db.getReference("Users");
        Users user = new Users(email);
        reference.child(mAuth.getCurrentUser().getUid()).setValue(user)
                .addOnCompleteListener(task -> {
                    Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show();
                });
    }

    private void sendUserToNextActivity() {
        Intent intent = new Intent(this, ActivityLogin.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}