package com.example.moaaa;

public class FirebaseAuth {
    public static com.example.moaaa.FirebaseAuth getInstance() {
        return null;
    }

    public FirebaseUser getCurrentUser() {
        return null;
    }

    public Object createUserWithEmailAndPassword(String email, String password) {
        return null;
    }

    public Object signInWithEmailAndPassword(String email, String password) {
        return null;
    }
}
