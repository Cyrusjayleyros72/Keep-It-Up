package com.example.moaaa;

public class FirebaseFirestoreException {
}
