package com.example.moaaa;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public interface InterFaceFireBase {
    View onCreateView(LayoutInflater inflater, ViewGroup container,
                      Bundle savedInstanceState);

    View onCreate(LayoutInflater inflater, ViewGroup container,
                  Bundle savedInstanceState);
}
