package com.example.moaaa;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityBmi extends AppCompatActivity {

    TextView mbmidisplay, mbmicategory, mgender;
    Button mgotomain;
    ImageView mimageview;
    RelativeLayout mbackground;

    @SuppressLint({"ResourceAsColor", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);

        // Initialize Views
        mbmidisplay = findViewById(R.id.bmidisplay);
        mbmicategory = findViewById(R.id.bmicategorydispaly);
        mgotomain = findViewById(R.id.gotomain);
        mimageview = findViewById(R.id.imageview);
        mgender = findViewById(R.id.genderdisplay);
        mbackground = findViewById(R.id.contentlayout);

        // Get Data from Intent
        Intent intent = getIntent();
        String heightStr = intent.getStringExtra("height");
        String weightStr = intent.getStringExtra("weight");
        String genderStr = intent.getStringExtra("gender");

        // Validate inputs
        if (heightStr == null || weightStr == null || heightStr.isEmpty() || weightStr.isEmpty()) {
            mbmidisplay.setText("Invalid Input");
            mbmicategory.setText("Error");
            return;
        }

        try {
            float height = Float.parseFloat(heightStr) / 100; // convert cm to meters
            float weight = Float.parseFloat(weightStr);
            float bmi = weight / (height * height);

            @SuppressLint("DefaultLocale") String bmiResult = String.format("%.1f", bmi);
            mbmidisplay.setText(bmiResult);
            mgender.setText(genderStr != null ? genderStr : "N/A");

            // Determine Category and Set Background & Icon
            if (bmi < 16) {
                setResultUI("Severe Thinness", Color.RED, R.drawable.crosss);
            } else if (bmi < 17) {
                setResultUI("Moderate Thinness", getColor(R.color.halfwarn), R.drawable.warning);
            } else if (bmi < 18.5) {
                setResultUI("Mild Thinness", getColor(R.color.halfwarn), R.drawable.warning);
            } else if (bmi < 25) {
                setResultUI("Normal", getColor(android.R.color.transparent), R.drawable.ok);
            } else if (bmi < 30) {
                setResultUI("Overweight", getColor(R.color.halfwarn), R.drawable.warning);
            } else if (bmi < 35) {
                setResultUI("Obese Class I", getColor(R.color.halfwarn), R.drawable.warning);
            } else {
                setResultUI("Obese Class II", getColor(R.color.warn), R.drawable.crosss);
            }

        } catch (NumberFormatException e) {
            mbmidisplay.setText("Error");
            mbmicategory.setText("Invalid number");
        }

        // Button Click
        mgotomain.setOnClickListener(v -> {
            startActivity(new Intent(getApplicationContext(), BmiActivityCalc.class));
            finish();
        });
    }

    private void setResultUI(String category, int color, int imageResId) {
        mbmicategory.setText(category);
        mbackground.setBackgroundColor(color);
        mimageview.setImageResource(imageResId);
    }
}
